package Pong;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Font;

public class PongGame extends JFrame {
    public PongGame() {
        setTitle("Pong Game");
        setSize(816, 600); // tamaño, no toquwn.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); //esto es lo q hubieramos puesto para centrar la pantalla en calc
        
        PanelGame gamePanel = new PanelGame();
        getContentPane().add(gamePanel); // como no se usa window para el juego, de aca se puede ver desde la persp de window!!!!!
        gamePanel.setLayout(null);
        
        setVisible(true);
    }

    public static void main(String[] args) {
        new PongGame();
    }
}


