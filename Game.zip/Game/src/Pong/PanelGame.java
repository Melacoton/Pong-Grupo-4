package Pong;

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Font;

public class PanelGame extends JPanel implements ActionListener, KeyListener {
    private int ballX = 400, ballY = 300;
    private int ballVelocityX = 2, ballVelocityY = 2;
    private int paddle1Y = 250, paddle2Y = 250;
    private int paddleWidth = 10, paddleHeight = 60;
    private int puntuacionA = 0, puntuacionB = 0;
    private Timer timer;
    
    public PanelGame() {
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);

        timer = new Timer(10, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        g.setColor(Color.WHITE);
        g.fillRect(ballX, ballY, 10, 10);
        g.fillRect(50, paddle1Y, paddleWidth, paddleHeight);
        g.fillRect(740, paddle2Y, paddleWidth, paddleHeight);
        
        g.setColor(Color.WHITE);
        for (int i = 0; i < getHeight(); i += 15) {
            g.drawLine(getWidth() / 2, i, getWidth() / 2, i + 10);
        }
        g.setFont(new Font("Yu Gothic UI", Font.PLAIN, 15));
        
        g.drawString("Neymar: " + puntuacionA, 100, 50);
        g.drawString("Messi: " + puntuacionB, 600, 50);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        ballX += ballVelocityX;
        ballY += ballVelocityY;

        if (ballY <= 0 || ballY >= getHeight() - 10) {
            ballVelocityY = -ballVelocityY;
        }

        if ((ballX <= 60 && ballY >= paddle1Y && ballY <= paddle1Y + paddleHeight) || (ballX >= 730 && ballY >= paddle2Y && ballY <= paddle2Y + paddleHeight)) { //rebote x2 pero de barras
            ballVelocityX = -ballVelocityX;
        }

        if (ballX < 0) {
        	puntuacionB++;
            ballX = 400;
            ballY = 300;
        } else if (ballX > 800) {
        	puntuacionA++;
            ballX = 400;
            ballY = 300;
        }

        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_W && paddle1Y > 0) {
            paddle1Y -= 10;
        }
        if (e.getKeyCode() == KeyEvent.VK_S && paddle1Y < getHeight() - paddleHeight) {
            paddle1Y += 10;
        }

        if (e.getKeyCode() == KeyEvent.VK_UP && paddle2Y > 0) {
            paddle2Y -= 10;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN && paddle2Y < getHeight() - paddleHeight) {
            paddle2Y += 10;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e) {}
}
