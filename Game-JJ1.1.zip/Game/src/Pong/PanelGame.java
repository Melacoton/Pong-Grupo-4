package Pong;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Font;

public class PanelGame extends JPanel implements ActionListener, KeyListener {
    private int ballX = 400, ballY = 300;
    private int ballVelocityX = 2, ballVelocityY = 2;
    private int ballSize = 30;
    private int paddle1Y = 250, paddle2Y = 250;
    private int paddleWidth = 10, paddleHeight = 60;
    private int puntuacionA = 0, puntuacionB = 0;
    private Timer timer;
    private int tiempoPorMitad = 60;
    private int tiempoRestante = tiempoPorMitad;
    private Timer timerJuego;
    private boolean primerTiempo = true;
    private boolean segundoTiempo = false;
    private boolean juegoTerminado = false;
    private String ganador = "";
    private boolean paddle1Up = false;
    private boolean paddle1Down = false;
    private boolean paddle2Up = false;
    private boolean paddle2Down = false;
    private int paddleSpeed = 6;
    private Image fondo;
    private Image pelota;

    public PanelGame() {
        fondo = new ImageIcon(getClass().getResource("/imagenes/Fondo.jpg")).getImage();
        pelota = new ImageIcon(getClass().getResource("/imagenes/Pelota.png")).getImage();

        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(10, this);
        timer.start();
        timerJuego = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tiempoRestante--;
                if (tiempoRestante <= 0) {
                    if (primerTiempo) {
                        cambiarMitad();
                        segundoTiempo = true;
                    } else {
                        finalizarJuego();
                    }
                }
                repaint();
            }
        });
        timerJuego.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
        g2d.drawImage(pelota, ballX, ballY, ballSize, ballSize, this);
        g.setColor(Color.WHITE);
        g.fillRect(50, paddle1Y, paddleWidth, paddleHeight);
        g.fillRect(740, paddle2Y, paddleWidth, paddleHeight);
        g.setColor(Color.WHITE);
        for (int i = 0; i < getHeight(); i += 15) {
            g.drawLine(getWidth() / 2, i, getWidth() / 2, i + 10);
        }
        g.setFont(new Font("Yu Gothic UI", Font.PLAIN, 20));
        String jugador1 = primerTiempo ? "Neymar" : "Messi";
        String jugador2 = primerTiempo ? "Messi" : "Neymar";
        g.drawString(jugador1 + ": " + puntuacionA, 100, 50);
        g.drawString(jugador2 + ": " + puntuacionB, 600, 50);
        g.drawString("Tiempo: " + tiempoRestante, getWidth() / 2 - 30, 50);
        g.drawString(primerTiempo ? "  Primer Tiempo" : "Segundo Tiempo", getWidth() / 2 - 50, 70);
        if (juegoTerminado) {
            g.setFont(new Font("Yu Gothic UI", Font.BOLD, 40));
            g.drawString("¡" + ganador + " es el ganador!", getWidth() / 2 - 165, getHeight() / 2);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!juegoTerminado) {
            moverPaletas();
            moverPelota();
            checkColisiones();
            repaint();
        }
    }

    private void moverPaletas() {
        if (primerTiempo) {
            if (paddle1Up && paddle1Y > 0) {
                paddle1Y -= paddleSpeed;
            }
            if (paddle1Down && paddle1Y < getHeight() - paddleHeight) {
                paddle1Y += paddleSpeed;
            }
            if (paddle2Up && paddle2Y > 0) {
                paddle2Y -= paddleSpeed;
            }
            if (paddle2Down && paddle2Y < getHeight() - paddleHeight) {
                paddle2Y += paddleSpeed;
            }
        } else if (segundoTiempo) {
            if (paddle1Up && paddle2Y > 0) {
                paddle2Y -= paddleSpeed;
            }
            if (paddle1Down && paddle2Y < getHeight() - paddleHeight) {
                paddle2Y += paddleSpeed;
            }
            if (paddle2Up && paddle1Y > 0) {
                paddle1Y -= paddleSpeed;
            }
            if (paddle2Down && paddle1Y < getHeight() - paddleHeight) {
                paddle1Y += paddleSpeed;
            }
        }
    }

    private void moverPelota() {
        ballX += ballVelocityX;
        ballY += ballVelocityY;
        if (ballY <= 0 || ballY + ballSize >= getHeight()) {
            ballVelocityY = -ballVelocityY;
        }
        if (ballX < 0) {
            puntuacionB++;
            reiniciarPelota();
            verificarFinalizacion();
        } else if (ballX + ballSize > getWidth()) {
            puntuacionA++;
            reiniciarPelota();
            verificarFinalizacion();
        }
    }

    private void checkColisiones() {
        Rectangle ball = new Rectangle(ballX, ballY, ballSize, ballSize);
        Rectangle paddle1 = new Rectangle(50, paddle1Y, paddleWidth, paddleHeight);
        Rectangle paddle2 = new Rectangle(740, paddle2Y, paddleWidth, paddleHeight);
        if (ball.intersects(paddle1) || ball.intersects(paddle2)) {
            ballVelocityX = -ballVelocityX;
            int randomAngle = (int) (Math.random() * 3) - 1;
            ballVelocityY += randomAngle;
            ballVelocityY = Math.max(-5, Math.min(5, ballVelocityY));
            if (ballVelocityX > 0) {
                ballVelocityX++;
            } else {
                ballVelocityX--;
            }

            ballVelocityX = Math.max(-8, Math.min(8, ballVelocityX));
        }
    }

    private void reiniciarPelota() {
        ballX = getWidth() / 2 - ballSize / 2;
        ballY = getHeight() / 2 - ballSize / 2;
        ballVelocityX = (Math.random() > 0.5) ? 2 : -2;
        ballVelocityY = (Math.random() > 0.5) ? 2 : -2;
    }

    private void cambiarMitad() {
        primerTiempo = false;
        tiempoRestante = tiempoPorMitad;
        int tempPuntuacion = puntuacionA;
        puntuacionA = puntuacionB;
        puntuacionB = tempPuntuacion;
        reiniciarPelota();
    }

    private void verificarFinalizacion() {
        if (puntuacionA >= 7 || puntuacionB >= 7) {
            if (Math.abs(puntuacionA - puntuacionB) >= 2) {
                finalizarJuego();
            }
        }
    }

    private void finalizarJuego() {
        if (juegoTerminado) return;  // Asegura que no se ejecute más de una vez
        timer.stop();
        timerJuego.stop();
        juegoTerminado = true;
        if (puntuacionA > puntuacionB) {
            ganador = primerTiempo ? "Neymar" : "Messi";
        } else if (puntuacionB > puntuacionA) {
            ganador = primerTiempo ? "Messi" : "Neymar";
        } else {
            ganador = "empate";
        }
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (!juegoTerminado) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W:
                    paddle1Up = true;
                    break;
                case KeyEvent.VK_S:
                    paddle1Down = true;
                    break;
                case KeyEvent.VK_UP:
                    paddle2Up = true;
                    break;
                case KeyEvent.VK_DOWN:
                    paddle2Down = true;
                    break;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W:
                paddle1Up = false;
                break;
            case KeyEvent.VK_S:
                paddle1Down = false;
                break;
            case KeyEvent.VK_UP:
                paddle2Up = false;
                break;
            case KeyEvent.VK_DOWN:
                paddle2Down = false;
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}
}